package javaCollections.question1;

import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.TreeMap;

public class SortedHashMap {
	public static void main(String args[]) {
		HashMap<Integer,Integer> hm=new HashMap<Integer,Integer>();
		Scanner s =new Scanner(System.in);
		int n=s.nextInt(); //input number of key value pairs
		int key,value;
		int num;
		try {
		while(n>0) { //Enter space separated key and value
			key=s.nextInt();
			value=s.nextInt();
			hm.put(key, value);
			n--;
		}
		TreeMap<Integer, Integer> tm = new TreeMap<Integer, Integer>(hm); //storing hashmap in TreeMap to sort according to keys 
		for (Entry<Integer, Integer> entry : tm.entrySet()) {
		    System.out.println("Key : "+entry.getKey() + " Value :  " + entry.getValue());
		}
		}catch(Exception e) {
			 System.out.println("Exception Caught");
		}
	}
}
