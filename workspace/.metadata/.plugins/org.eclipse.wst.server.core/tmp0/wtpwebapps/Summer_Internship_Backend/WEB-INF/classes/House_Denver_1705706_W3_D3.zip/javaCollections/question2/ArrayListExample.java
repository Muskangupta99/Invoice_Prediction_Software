package javaCollections.question2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class ArrayListExample {
	public static void main(String args[]) {
		 ArrayList<String> list = new ArrayList<String>();
         Scanner s=new Scanner(System.in);
         int n=s.nextInt();//enter number of elements;
         try {
         for(int i=0;i<n;i++) {
        	 //enter elements
        	 list.add(s.next());
         }
	     System.out.println(list);  
	     System.out.println("Enter index number and element to add");
	     int index=s.nextInt();
	     String element=s.next();
	        list.add(index, element);
	         
	        System.out.println(list); 
         }catch(Exception e) {
        	 System.out.println("Exception Caught,one reason could be more number of elements than specified");
         }
	}
}
