package jdbc.question1;

import java.util.ArrayList;

public class TestTablePojo {
	String First_Name;
	String Last_Name;
	String serial_number;
	String also_known_as;
	String moto;
	ArrayList<String> list=new ArrayList<String>();
	public void setList(ArrayList<String> list) {
		First_Name=list.get(0);
		Last_Name=list.get(1);
		serial_number=list.get(2);
		also_known_as=list.get(3);
		moto=list.get(4);
	}
	public String getFirst_Name() {
		return First_Name;
	}
	public void setFirst_Name(String first_Name) {
		First_Name = first_Name;
	}
	public String getLast_Name() {
		return Last_Name;
	}
	public void setLast_Name(String last_Name) {
		Last_Name = last_Name;
	}
	public String getSerial_number() {
		return serial_number;
	}
	public void setSerial_number(String serial_number) {
		this.serial_number = serial_number;
	}
	public String getAlso_known_as() {
		return also_known_as;
	}
	public void setAlso_known_as(String also_known_as) {
		this.also_known_as = also_known_as;
	}
	public String getMoto() {
		return moto;
	}
	public void setMoto(String moto) {
		this.moto = moto;
	}
	
	
}
