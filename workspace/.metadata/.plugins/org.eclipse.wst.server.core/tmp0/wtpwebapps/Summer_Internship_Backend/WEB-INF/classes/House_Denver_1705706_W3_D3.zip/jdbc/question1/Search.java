package jdbc.question1;

import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
import com.higradius.CustomerInvoicePojo;

public class Search {
	
  public static void main(String args[]) {
	Connection dbCon=null;
	String search_query=null;
	Statement stmt=null;
	ResultSet rs=null;
	PreparedStatement pstmt=null;
	
	String url="jdbc:mysql://localhost:3306/example_schema";
	
	try {
	Scanner s=new Scanner(System.in);
	String input = s.next();
	//Query for searching
	search_query ="SELECT * FROM test_table WHERE First_Name='"+input+"'OR Last_Name='"+input+"' OR serial_number='"+input+"' OR also_known_as='"+input+"' OR moto='"+input+"';";
	
	//Making connection
	Class.forName("com.mysql.jdbc.Driver");
    dbCon= DriverManager.getConnection(url, "root", "root");
    pstmt=dbCon.prepareStatement(search_query);
    
    rs=pstmt.executeQuery(search_query);
   
    if(dbCon.isClosed()) //throw exception if connection could not be made
		throw new Exception("Connection Cannot be made,please try again");
    if(rs.next()) { //if found then proceed 
    while(rs.next()) {
    	//print result
    	System.out.print("First Name: "+rs.getString(1)+", Last Name: "+rs.getString(2)+", Serial: "+rs.getString(3)+", Alias: "+rs.getString(4)+", Quote: "+rs.getString(5));
    

  }
    }else
    	System.out.println("Not Found"); //If not found,print error message
	}
	
	catch(Exception e) {
		System.out.println("Exception Caught");
	}
	
	finally {
		closeResource(pstmt);
		closeResource(stmt);
		closeResource(rs);
		closeResource(dbCon);
		
	}
  }
  
  //functions to close resources
  private static void closeResource(PreparedStatement pstmt) {
		 if (pstmt != null) {
		        try {
					pstmt.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
		    }
		
		
	}
	
	private static void closeResource(Statement pstmt) {
		 if (pstmt != null) {
		        try {
					pstmt.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
		    }
		
		
	}
	
	private static void closeResource(ResultSet pstmt) {
		 if (pstmt != null) {
		        try {
					pstmt.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
		    }
		
		
	}
	
	private static void closeResource(Connection con) {
		 if (con != null) {
		        try {
					con.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
		    }
		
		
	}
	
}
