package jdbc.question2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import jdbc.question1.TestTablePojo;

public class StoreData {
	public static void main(String args[]) {
		Connection dbCon=null;
		String dataQuery=null;
		Statement stmt=null;
		ResultSet rs=null;
		PreparedStatement pstmt=null;
		String url="jdbc:mysql://localhost:3306/example_schema";
		
		try {
		//Query to select the data to store in pojo
		dataQuery ="SELECT * FROM test_table";
		
		//make connection to database
		Class.forName("com.mysql.jdbc.Driver");
	    dbCon= DriverManager.getConnection(url, "root", "root");
	    pstmt=dbCon.prepareStatement(dataQuery);
	    
	    //Making Pojo object
	    TestTablePojo pojo=new TestTablePojo();
	    
	    rs=pstmt.executeQuery(dataQuery);
	   
	    
	    	if(dbCon.isClosed()) //Throw exception if connection to database was unsuccessful 
	    		throw new Exception("Connection Cannot be made,please try again");
	    	
	    
	   
	    while(rs.next()) {
	    	
	    	try { //throw exception if Serial number is not in digits
	    	Object serial=Integer.parseInt(rs.getString(3));
	    	
	    	
	    	
	    	for(int i=1; i<=5;i++){
	    		if(rs.getString(i)==null) 
	    			throw new Exception("Null Value Found") ;//throwing exception if null is trying to be stored in pojo
	    		if(rs.getString(i).length() > 2147483647 ) {
	    			throw new Exception("Too Long to Store in List") ;
	    		}
	    		
	    	if(serial instanceof Integer==false) { //throwing exception if there is a type mismatch
	    		throw new Exception("Serial Number should be in digits");
	    	}
	    		
	    	}
	    	//Storing in ArrayList to store in pojo
	    	ArrayList<String> list = new ArrayList<>(Arrays.asList(rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5)));
	    	//storing in pojo
	    	pojo.setList(list);
	    	
	    	System.out.println("Stored successfully");
	    	
	    	
	    	}
	    	catch(Exception e) {
	    		System.out.println(e);
	    	}
	    	
	    }

	  
	    
		}
		
		catch(Exception e) {
			System.out.println("Exception Caught");
		}
		finally { //closing resources
			closeResource(pstmt);
			closeResource(stmt);
			closeResource(rs);
			closeResource(dbCon);
			
		}
	  }
  //functions to close resources
	private static void closeResource(PreparedStatement pstmt) {
		 if (pstmt != null) {
		        try {
					pstmt.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
		    }
		
		
	}
	
	private static void closeResource(Statement pstmt) {
		 if (pstmt != null) {
		        try {
					pstmt.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
		    }
		
		
	}
	
	private static void closeResource(ResultSet pstmt) {
		 if (pstmt != null) {
		        try {
					pstmt.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
		    }
		
		
	}
	
	private static void closeResource(Connection con) {
		 if (con != null) {
		        try {
					con.close();
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
		    }
		
		
	}
	
	
}
